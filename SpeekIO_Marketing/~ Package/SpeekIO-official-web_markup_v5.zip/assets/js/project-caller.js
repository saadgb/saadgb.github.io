$(document).ready(function () {
    videoModal(); 
    gotoTop();
    toast();
});
