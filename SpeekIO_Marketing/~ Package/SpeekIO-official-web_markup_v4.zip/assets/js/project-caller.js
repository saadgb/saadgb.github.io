$(document).ready(function () {
    videoModal(); 
    gotoTop();
});
