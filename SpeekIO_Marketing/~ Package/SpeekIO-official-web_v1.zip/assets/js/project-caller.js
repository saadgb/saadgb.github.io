$(document).ready(function () {
    videoModal(); 
});
